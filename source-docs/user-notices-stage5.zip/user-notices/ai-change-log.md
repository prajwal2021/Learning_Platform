# AI change log

## 2026-10-14 app/services/notices.py schedule_notice
Decided: raise ValueError when send_at has no time zone, before comparing it
with the current time.
Why: comparing a datetime with no time zone to a UTC datetime raises TypeError,
which the router would return as a 500 error.
Open question: the comment does not list this ValueError.

## 2026-10-14 app/auth/credentials.py verify_credentials
Broke: sign-in returned 401 for a correct password when the email had capitals.
Why: the lookup compared the typed email with the stored lower-case email exactly.
Fixed: email trimmed and lowered before the lookup; rule added to the comment;
test_sign_in_accepts_mixed_case_email added.
