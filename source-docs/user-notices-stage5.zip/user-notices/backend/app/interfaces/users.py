# app/interfaces/users.py
from typing import Protocol
from pydantic import BaseModel, ConfigDict, Field, field_validator
from app.interfaces.auth import Staff

MAX_PAGE_SIZE = 200  # the most users one GET /v1/users call returns


class User(BaseModel):
    id: int
    name: str
    phone: str     # international format, for example +15555550101
    group_id: int
    opted_in: bool


class UserSummary(BaseModel):
    """One row of the Users list."""
    id: int
    name: str
    group_id: int
    opted_in: bool


class UserGroup(BaseModel):
    id: int
    name: str


class UserUpdate(BaseModel):
    """The fields a staff member may change. Any may be left out; none may be null.
    A request with any other field, such as group_id, is rejected with 422."""
    model_config = ConfigDict(extra="forbid")

    name: str | None = Field(default=None, min_length=1)
    phone: str | None = None
    opted_in: bool | None = None

    @field_validator("name", "phone", "opted_in", mode="before")
    @classmethod
    def not_null(cls, value):
        if value is None:
            raise ValueError("may be left out, but not set to null")
        return value


class UserService(Protocol):
    async def list_users(self, group_id: int | None = None, limit: int = 50,
                         offset: int = 0) -> list[UserSummary]: ...
    async def list_groups(self) -> list[UserGroup]: ...
    async def get_user(self, user_id: int) -> User: ...
    async def update_user(self, user_id: int, changes: UserUpdate, staff: Staff) -> User: ...


class UserStore(Protocol):
    async def list_users(self, group_id: int | None, limit: int, offset: int) -> list[UserSummary]: ...
    async def list_groups(self) -> list[UserGroup]: ...
    async def get_user(self, user_id: int) -> User | None: ...
    async def save_user(self, user: User) -> User: ...
