# app/interfaces/notices.py
from datetime import datetime
from typing import Protocol
from pydantic import BaseModel


class NoticeSummary(BaseModel):
    id: int
    text: str
    send_at: datetime
    status: str  # scheduled, sending, sent or failed


class Recipient(BaseModel):
    user_id: int
    phone: str


class NoticeService(Protocol):
    async def schedule_notice(self, text: str, group_id: int,
                              send_at: datetime, author_id: int) -> NoticeSummary: ...
    async def list_notices(self, limit: int = 50) -> list[NoticeSummary]: ...
    async def send_notice(self, notice_id: int) -> None: ...


class NoticeStore(Protocol):
    """What the notices service needs from the data layer."""
    async def group_exists(self, group_id: int) -> bool: ...
    async def add_notice(self, text: str, group_id: int, send_at: datetime,
                         author_id: int) -> NoticeSummary: ...
    async def get_notice(self, notice_id: int) -> NoticeSummary | None: ...
    async def list_notices(self, limit: int) -> list[NoticeSummary]: ...
    async def set_status(self, notice_id: int, status: str) -> None: ...
    async def list_recipients(self, notice_id: int) -> list[Recipient]: ...
    async def record_message(self, notice_id: int, user_id: int, status: str,
                             provider_message_id: str | None) -> None: ...
