# app/interfaces/auth.py
from typing import Literal, Protocol
from pydantic import BaseModel


class Staff(BaseModel):
    """The signed-in staff member, as current_user returns it."""
    id: int
    email: str                         # stored in lower case
    role: Literal["editor", "viewer"]  # editors change users and send notices; viewers only read


class StaffRecord(Staff):
    """A staff account as the store holds it. The hash stays inside auth/."""
    password_hash: str                 # "salt$hash", from hash_password


class StaffStore(Protocol):
    async def find_by_email(self, email: str) -> StaffRecord | None: ...
    async def get_staff(self, staff_id: int) -> Staff | None: ...
