# app/interfaces/sms.py
from typing import Protocol


class SmsError(Exception):
    """The provider did not accept a message."""


class SmsClient(Protocol):
    async def send(self, phone: str, text: str) -> str: ...  # the provider's message id; raises SmsError
