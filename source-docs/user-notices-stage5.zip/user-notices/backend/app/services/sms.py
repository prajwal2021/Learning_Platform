# app/services/sms.py
"""The SMS provider client. It implements SmsClient from app/interfaces/sms.py
with httpx.AsyncClient, reading SMS_API_URL and SMS_API_KEY from settings.
It is written and reviewed before the sandbox in Stage 9; until then
get_sms_client in app/db/stores.py returns FakeSmsClient from tests/stubs.py."""
