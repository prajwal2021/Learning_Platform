# app/services/users.py
from app.interfaces.auth import Staff
from app.interfaces.users import MAX_PAGE_SIZE, User, UserGroup, UserSummary, UserUpdate
from app.services.phones import format_phone


class Users:
    """Implements UserService from app/interfaces/users.py."""

    def __init__(self, store):
        self.store = store  # the users store: a stub until Stage 7

    async def list_users(self, group_id: int | None = None, limit: int = 50,
                         offset: int = 0) -> list[UserSummary]:
        # Return one page of users ordered by id: all users, or only the users
        # in group_id when it is given.
        # Depends on: self.store.
        # Raises ValueError if limit is not between 1 and MAX_PAGE_SIZE (200),
        # or offset is negative.
        if not 1 <= limit <= MAX_PAGE_SIZE:
            raise ValueError(f"limit must be between 1 and {MAX_PAGE_SIZE}")
        if offset < 0:
            raise ValueError("offset must be 0 or more")
        return await self.store.list_users(group_id, limit, offset)

    async def list_groups(self) -> list[UserGroup]:
        # Return every user group, ordered by name.
        # Depends on: self.store.
        return await self.store.list_groups()

    async def get_user(self, user_id: int) -> User:
        # Return one user.
        # Depends on: self.store.
        # Raises LookupError for an unknown user_id.
        user = await self.store.get_user(user_id)
        if user is None:
            raise LookupError(f"Unknown user {user_id}")
        return user

    async def update_user(self, user_id: int, changes: UserUpdate, staff: Staff) -> User:
        # Apply the fields that are set in changes and return the updated user.
        # changes holds only the fields a staff member may change (UserUpdate).
        # Depends on: self.store, get_user, format_phone.
        # Raises PermissionError unless staff.role is "editor"; LookupError for
        # an unknown user_id; ValueError for a phone number format_phone rejects.
        # Does not send any messages. From Stage 7 it also writes an audit record.
        if staff.role != "editor":
            raise PermissionError(f"Staff {staff.id} may not change users")
        user = await self.get_user(user_id)
        updates = changes.model_dump(exclude_unset=True)
        if "phone" in updates:
            updates["phone"] = format_phone(updates["phone"])
        return await self.store.save_user(user.model_copy(update=updates))
