# app/services/phones.py
import phonenumbers


def format_phone(raw: str) -> str:
    # Return the number in international (E.164) form, for example +15555550101.
    # Accepts spaces, dots, hyphens and brackets; the number must start with +.
    # Depends on: the phonenumbers library.
    # Raises ValueError for text that is not a possible phone number.
    try:
        number = phonenumbers.parse(raw, None)
    except phonenumbers.NumberParseException as e:
        raise ValueError("Phone number must be in international format, starting with +") from e
    if not phonenumbers.is_possible_number(number):
        raise ValueError("Phone number has the wrong number of digits")
    return phonenumbers.format_number(number, phonenumbers.PhoneNumberFormat.E164)
