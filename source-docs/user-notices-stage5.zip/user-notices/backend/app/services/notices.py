# app/services/notices.py
import logging
from datetime import datetime, timezone
from app.interfaces.notices import NoticeSummary
from app.interfaces.sms import SmsError

log = logging.getLogger("user_notices.notices")


class Notices:
    """Implements NoticeService from app/interfaces/notices.py."""

    def __init__(self, store, sms=None):
        self.store = store  # the notices store: a stub until Stage 7
        self.sms = sms      # the SMS client; only send_notice uses it

    async def schedule_notice(self, text: str, group_id: int,
                              send_at: datetime, author_id: int) -> NoticeSummary:
        # Store a notice with status "scheduled" for the group and send time.
        # send_at is a timezone-aware UTC datetime.
        # Depends on: self.store.
        # Raises ValueError for: empty text, an unknown group, a past send time,
        # a send_at with no time zone.
        # Does not send any messages; send_notice does that.
        if not text.strip():
            raise ValueError("Notice text is empty")
        if send_at.tzinfo is None:
            raise ValueError("send_at must include a time zone")
        if send_at <= datetime.now(timezone.utc):
            raise ValueError("Send time is in the past")
        if not await self.store.group_exists(group_id):
            raise ValueError(f"Unknown group {group_id}")
        return await self.store.add_notice(text, group_id, send_at, author_id)

    async def list_notices(self, limit: int = 50) -> list[NoticeSummary]:
        # Return up to limit notices, latest send time first.
        # Depends on: self.store.
        # Raises ValueError if limit is not between 1 and 200.
        if not 1 <= limit <= 200:
            raise ValueError("limit must be between 1 and 200")
        return await self.store.list_notices(limit)

    async def send_notice(self, notice_id: int) -> None:
        # Send the notice text by SMS to every opted-in user in its group.
        # Depends on: self.store, self.sms.
        # Sets status "sending" before the first message, then "sent", or
        # "failed" if any message failed. Records one message per recipient,
        # with the provider's message id when the provider accepted it.
        # Logs a failed message with the user id, never the phone number.
        # Raises LookupError for an unknown notice; ValueError if its status
        # is not "scheduled".
        # Runs inside the request until Stage 8 moves it to a worker.
        notice = await self.store.get_notice(notice_id)
        if notice is None:
            raise LookupError(f"Unknown notice {notice_id}")
        if notice.status != "scheduled":
            raise ValueError(f"Notice {notice_id} is {notice.status}, not scheduled")
        await self.store.set_status(notice_id, "sending")
        all_sent = True
        for recipient in await self.store.list_recipients(notice_id):
            try:
                message_id = await self.sms.send(recipient.phone, notice.text)
            except SmsError:
                log.warning("SMS failed: notice %s, user %s", notice_id, recipient.user_id)
                await self.store.record_message(notice_id, recipient.user_id, "failed", None)
                all_sent = False
            else:
                await self.store.record_message(notice_id, recipient.user_id, "sent", message_id)
        await self.store.set_status(notice_id, "sent" if all_sent else "failed")
