# app/settings.py
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Every setting the backend reads. Each value comes from an environment
    variable of the same name in capitals, or from .env in the folder the
    service starts in. A missing setting stops startup with an error naming it."""

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: str         # used from Stage 7
    session_secret: str       # signs the session cookie
    sms_api_url: str          # used by the provider client from Stage 9
    sms_api_key: str
    allowed_origin: str       # used by CORS in Stage 6
    stub_staff_password: str  # Stage 5 stub only: password of the seeded accounts; removed in Stage 7


settings = Settings()
