# app/db/stores.py
"""Hands out the data stores and the SMS client through Depends.
Stage 5: the in-memory stubs from tests/stubs.py, seeded with sample records.
Stage 7 changes these functions to return PostgreSQL-backed stores, and removes
the import from tests/ and the STUB_STAFF_PASSWORD setting."""
from app.auth.passwords import hash_password
from app.interfaces.auth import StaffRecord
from app.interfaces.users import User, UserGroup
from app.settings import settings
from tests.stubs import FakeSmsClient, InMemoryNoticeStore, InMemoryStaffStore, InMemoryUserStore

_stub_hash = hash_password(settings.stub_staff_password)
_staff = InMemoryStaffStore([
    StaffRecord(id=1, email="staff.member@example.org", role="editor", password_hash=_stub_hash),
    StaffRecord(id=2, email="viewer@example.org", role="viewer", password_hash=_stub_hash),
])
_users = InMemoryUserStore(
    users=[
        User(id=1, name="Sample User 1", phone="+15555550101", group_id=1, opted_in=True),
        User(id=2, name="Sample User 2", phone="+15555550102", group_id=1, opted_in=True),
        User(id=3, name="Sample User 3", phone="+15555550103", group_id=1, opted_in=False),
        User(id=4, name="Sample User 4", phone="+15555550104", group_id=2, opted_in=True),
    ],
    groups=[UserGroup(id=1, name="Group 1"), UserGroup(id=2, name="Group 2")],
)
_notices = InMemoryNoticeStore(group_ids=[1, 2], users=_users)
_sms = FakeSmsClient()


def get_staff_store():
    return _staff


def get_user_store():
    return _users


def get_notice_store():
    return _notices


def get_sms_client():
    return _sms
