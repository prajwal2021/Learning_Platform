# app/routers/users.py
import logging
from fastapi import APIRouter, Depends, HTTPException
from app.auth.sessions import current_user
from app.db.stores import get_user_store
from app.interfaces.auth import Staff
from app.interfaces.users import User, UserGroup, UserSummary, UserUpdate
from app.services.users import Users

router = APIRouter(prefix="/users", tags=["users"])
log = logging.getLogger("user_notices.users")


def get_users(store=Depends(get_user_store)) -> Users:
    return Users(store)


@router.get("")
async def list_users(group: int | None = None, limit: int = 50, offset: int = 0,
                     staff: Staff = Depends(current_user),
                     users: Users = Depends(get_users)) -> list[UserSummary]:
    try:
        return await users.list_users(group, limit, offset)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


# Declared before /{user_id}, so that "groups" is not read as a user id.
@router.get("/groups")
async def list_groups(staff: Staff = Depends(current_user),
                      users: Users = Depends(get_users)) -> list[UserGroup]:
    return await users.list_groups()


@router.get("/{user_id}")
async def get_user(user_id: int, staff: Staff = Depends(current_user),
                   users: Users = Depends(get_users)) -> User:
    try:
        return await users.get_user(user_id)
    except LookupError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.patch("/{user_id}")
async def update_user(user_id: int, changes: UserUpdate,
                      staff: Staff = Depends(current_user),
                      users: Users = Depends(get_users)) -> User:
    try:
        return await users.update_user(user_id, changes, staff)
    except PermissionError:
        log.warning("denied: staff %s may not change user %s", staff.id, user_id)
        raise HTTPException(status_code=403, detail="Your role cannot change users")
    except LookupError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
