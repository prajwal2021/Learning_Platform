# app/routers/auth.py
from fastapi import APIRouter, HTTPException, Response
from pydantic import BaseModel, Field
from app.auth.credentials import verify_credentials
from app.auth.sessions import issue_token

router = APIRouter(prefix="/auth", tags=["auth"])


class SignIn(BaseModel):
    email: str = Field(max_length=254)
    password: str = Field(max_length=200)


@router.post("/login", status_code=204)
async def login(body: SignIn, response: Response) -> None:
    staff = await verify_credentials(body.email, body.password)
    if staff is None:
        raise HTTPException(status_code=401, detail="Wrong email or password")
    response.set_cookie("session", issue_token(staff.id), httponly=True, samesite="lax")
