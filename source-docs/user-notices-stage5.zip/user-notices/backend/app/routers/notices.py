# app/routers/notices.py
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from app.auth.sessions import current_user, require_editor
from app.db.stores import get_notice_store, get_sms_client
from app.interfaces.auth import Staff
from app.interfaces.notices import NoticeSummary
from app.services.notices import Notices

router = APIRouter(prefix="/notices", tags=["notices"])


class NewNotice(BaseModel):
    text: str = Field(max_length=640)
    group_id: int
    send_at: datetime


def get_notices(store=Depends(get_notice_store), sms=Depends(get_sms_client)) -> Notices:
    return Notices(store, sms)


@router.post("", status_code=201)
async def create_notice(body: NewNotice, staff: Staff = Depends(require_editor),
                        notices: Notices = Depends(get_notices)) -> NoticeSummary:
    try:
        return await notices.schedule_notice(body.text, body.group_id, body.send_at, staff.id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("")
async def list_notices(limit: int = 50, staff: Staff = Depends(current_user),
                       notices: Notices = Depends(get_notices)) -> list[NoticeSummary]:
    try:
        return await notices.list_notices(limit)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/{notice_id}/send", status_code=204)
async def send_now(notice_id: int, staff: Staff = Depends(require_editor),
                   notices: Notices = Depends(get_notices)) -> None:
    try:
        await notices.send_notice(notice_id)
    except LookupError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=409, detail=str(e))
