# app/main.py
from fastapi import FastAPI
from app.routers import auth, users, notices

app = FastAPI(title="User Notices")

# Each router sets its own path, for example APIRouter(prefix="/notices").
# Sign-in and tokens: routers/auth.py, auth/
app.include_router(auth.router, prefix="/v1")
# List, view and edit users: routers/users.py, services/users.py
app.include_router(users.router, prefix="/v1")
# Notices: routers/notices.py, services/notices.py, services/sms.py
app.include_router(notices.router, prefix="/v1")
