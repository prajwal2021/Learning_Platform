# app/auth/passwords.py
import hashlib
import hmac
import secrets

ITERATIONS = 600_000


def hash_password(password: str, salt: str | None = None) -> str:
    # Return "salt$hash" for a password, using PBKDF2-SHA256.
    # Makes a new random salt when salt is None.
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), ITERATIONS)
    return f"{salt}${digest.hex()}"


def check_password(password: str, stored: str) -> bool:
    # Return True if password matches a "salt$hash" value from hash_password.
    # Compares in constant time.
    salt = stored.split("$", 1)[0]
    return hmac.compare_digest(hash_password(password, salt), stored)
