# app/auth/__init__.py
"""Sign-in and sessions.

credentials.py: verify_credentials(email, password) -> Staff | None
sessions.py: issue_token, current_user (returns the signed-in Staff), require_editor
passwords.py: hash_password, check_password
"""
