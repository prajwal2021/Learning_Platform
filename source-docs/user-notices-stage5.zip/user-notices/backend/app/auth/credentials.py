# app/auth/credentials.py
import logging
from app.auth.passwords import check_password, hash_password
from app.db.stores import get_staff_store
from app.interfaces.auth import Staff

log = logging.getLogger("user_notices.auth")

# Checked when the email is unknown, so that case takes as long as a wrong password.
_PLACEHOLDER_HASH = hash_password("placeholder")


async def verify_credentials(email: str, password: str) -> Staff | None:
    # Return the staff member if the email and password match an account,
    # otherwise None.
    # Depends on: get_staff_store, check_password.
    # Compares email addresses in lower case, after trimming spaces.
    # Checks the password against a placeholder hash when the email is unknown,
    # so the response time does not show which accounts exist.
    # Logs each failure with the email address; never logs the password.
    # Does not say which of the two was wrong.
    address = email.strip().lower()
    record = await get_staff_store().find_by_email(address)
    stored = record.password_hash if record else _PLACEHOLDER_HASH
    if not check_password(password, stored) or record is None:
        log.warning("sign-in failed for %s", address)
        return None
    return Staff(id=record.id, email=record.email, role=record.role)
