# app/auth/sessions.py
import hashlib
import hmac
import logging
import time
from fastapi import Cookie, Depends, HTTPException
from app.db.stores import get_staff_store
from app.interfaces.auth import Staff
from app.settings import settings

TOKEN_HOURS = 8
log = logging.getLogger("user_notices.auth")


def _sign(payload: str) -> str:
    return hmac.new(settings.session_secret.encode(), payload.encode(), hashlib.sha256).hexdigest()


def issue_token(staff_id: int) -> str:
    # Return a signed session token for staff_id that expires in TOKEN_HOURS.
    # Depends on: settings.session_secret.
    expires = int(time.time()) + TOKEN_HOURS * 3600
    payload = f"{staff_id}.{expires}"
    return f"{payload}.{_sign(payload)}"


async def current_user(session: str | None = Cookie(default=None),
                       staff=Depends(get_staff_store)) -> Staff:
    # Return the signed-in staff member from the session cookie.
    # Received through Depends by every route except sign-in.
    # Depends on: staff, a StaffStore.
    # Raises HTTPException 401 for a missing, altered or expired token, or for
    # an account that no longer exists.
    parts = (session or "").split(".")
    if len(parts) != 3 or not (parts[0].isdigit() and parts[1].isdigit()):
        raise HTTPException(status_code=401, detail="Not signed in")
    staff_id, expires, signature = parts
    if not hmac.compare_digest(_sign(f"{staff_id}.{expires}"), signature):
        raise HTTPException(status_code=401, detail="Not signed in")
    if int(expires) < time.time():
        raise HTTPException(status_code=401, detail="Session expired")
    member = await staff.get_staff(int(staff_id))
    if member is None:
        raise HTTPException(status_code=401, detail="Not signed in")
    return member


async def require_editor(staff: Staff = Depends(current_user)) -> Staff:
    # Return the signed-in staff member if their role is editor.
    # Received through Depends by routes that change notices.
    # Raises HTTPException 403 for a viewer, and logs the denied request.
    if staff.role != "editor":
        log.warning("denied: staff %s has role %s", staff.id, staff.role)
        raise HTTPException(status_code=403, detail="Your role cannot do this")
    return staff
