# tests/test_auth.py
import time
import pytest
from fastapi import HTTPException
from app.auth import credentials
from app.auth.credentials import verify_credentials
from app.auth.sessions import current_user, issue_token, require_editor
from app.interfaces.auth import Staff, StaffRecord
from tests.stubs import InMemoryStaffStore

PASSWORD = "test-only-password"  # STUB_STAFF_PASSWORD in tests/conftest.py


def staff_store():
    return InMemoryStaffStore([StaffRecord(id=7, email="staff.member@example.org",
                                           role="editor", password_hash="unused")])


@pytest.mark.asyncio
async def test_sign_in_accepts_mixed_case_email():
    staff = await verify_credentials("Staff.Member@example.org", PASSWORD)
    assert staff == Staff(id=1, email="staff.member@example.org", role="editor")


@pytest.mark.asyncio
async def test_sign_in_rejects_wrong_password():
    assert await verify_credentials("staff.member@example.org", "wrong") is None


@pytest.mark.asyncio
async def test_sign_in_rejects_unknown_email():
    assert await verify_credentials("nobody@example.org", PASSWORD) is None


@pytest.mark.asyncio
async def test_unknown_email_still_checks_a_password(monkeypatch):
    checked = []

    def counting_check(password, stored):
        checked.append(stored)
        return False

    monkeypatch.setattr(credentials, "check_password", counting_check)
    assert await verify_credentials("nobody@example.org", PASSWORD) is None
    assert len(checked) == 1


@pytest.mark.asyncio
async def test_sign_in_failure_is_logged_without_the_password(caplog):
    await verify_credentials("staff.member@example.org", "wrong-password-123")
    assert "sign-in failed for staff.member@example.org" in caplog.text
    assert "wrong-password-123" not in caplog.text


@pytest.mark.asyncio
async def test_token_round_trip_returns_the_staff_member():
    staff = await current_user(issue_token(7), staff=staff_store())
    assert staff == Staff(id=7, email="staff.member@example.org", role="editor")


@pytest.mark.asyncio
async def test_altered_token_is_rejected():
    token = issue_token(7)
    with pytest.raises(HTTPException) as caught:
        await current_user("8" + token[1:], staff=staff_store())
    assert caught.value.status_code == 401


@pytest.mark.asyncio
async def test_missing_token_is_rejected():
    with pytest.raises(HTTPException) as caught:
        await current_user(None, staff=staff_store())
    assert caught.value.status_code == 401


@pytest.mark.asyncio
async def test_expired_token_is_rejected(monkeypatch):
    token = issue_token(7)
    nine_hours_later = time.time() + 9 * 3600
    monkeypatch.setattr(time, "time", lambda: nine_hours_later)
    with pytest.raises(HTTPException) as caught:
        await current_user(token, staff=staff_store())
    assert caught.value.detail == "Session expired"


@pytest.mark.asyncio
async def test_require_editor_denies_a_viewer():
    viewer = Staff(id=2, email="viewer@example.org", role="viewer")
    with pytest.raises(HTTPException) as caught:
        await require_editor(viewer)
    assert caught.value.status_code == 403
