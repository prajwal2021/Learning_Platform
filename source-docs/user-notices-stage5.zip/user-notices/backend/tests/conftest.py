# tests/conftest.py
import os

# Test values for every setting. Environment variables take priority over .env,
# so the tests never use the values on your machine, and CI needs no .env file.
for name, value in {
    "DATABASE_URL": "postgresql+psycopg://test:test@localhost:5432/test",
    "SESSION_SECRET": "test-only-secret",
    "SMS_API_URL": "https://sms.example.invalid/v1",
    "SMS_API_KEY": "test-only-key",
    "ALLOWED_ORIGIN": "http://localhost:3000",
    "STUB_STAFF_PASSWORD": "test-only-password",
}.items():
    os.environ[name] = value
