# tests/test_phones.py
import pytest
from app.services.phones import format_phone


@pytest.mark.parametrize("raw", ["+15555550101", "+1 555 555 0101", "+1 (555) 555-0101", "+1.555.555.0101"])
def test_format_phone_returns_e164(raw):
    assert format_phone(raw) == "+15555550101"


@pytest.mark.parametrize("raw", ["555-0101", "+1 555", "call me"])
def test_format_phone_rejects_text_that_is_not_a_number(raw):
    with pytest.raises(ValueError):
        format_phone(raw)
