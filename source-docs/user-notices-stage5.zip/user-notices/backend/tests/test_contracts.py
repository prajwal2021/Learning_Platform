# tests/test_contracts.py
# Fails if a service class adds, drops or changes a function from its interface.
import inspect
from app.interfaces.notices import NoticeService
from app.interfaces.users import UserService
from app.services.notices import Notices
from app.services.users import Users

def differences(interface, service):
    wanted = {n: f for n, f in vars(interface).items() if inspect.isfunction(f) and not n.startswith("_")}
    built = {n: f for n, f in vars(service).items() if inspect.isfunction(f) and not n.startswith("_")}
    found = [f"{n}: missing" for n in wanted.keys() - built.keys()]
    found += [f"{n}: not in the interface" for n in built.keys() - wanted.keys()]
    found += [f"{n}: signature changed" for n in wanted.keys() & built.keys()
              if inspect.signature(wanted[n]) != inspect.signature(built[n])]
    return found

def test_notices_matches_its_interface():
    assert differences(NoticeService, Notices) == []

def test_users_matches_its_interface():
    assert differences(UserService, Users) == []
