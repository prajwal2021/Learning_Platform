# tests/stubs.py
"""Stand-ins for the data layer and the SMS provider. The unit tests use them,
and app/db/stores.py hands them to the running service until Stage 7.
They keep records in dictionaries and lose everything when the process stops."""
from datetime import datetime
from app.interfaces.auth import Staff, StaffRecord
from app.interfaces.notices import NoticeSummary, Recipient
from app.interfaces.sms import SmsError
from app.interfaces.users import User, UserGroup, UserSummary


class InMemoryStaffStore:
    def __init__(self, staff: list[StaffRecord] | None = None):
        self.by_email = {s.email: s for s in staff or []}

    async def find_by_email(self, email: str) -> StaffRecord | None:
        return self.by_email.get(email)

    async def get_staff(self, staff_id: int) -> Staff | None:
        for record in self.by_email.values():
            if record.id == staff_id:
                return Staff(id=record.id, email=record.email, role=record.role)
        return None


class InMemoryUserStore:
    def __init__(self, users: list[User] | None = None, groups: list[UserGroup] | None = None):
        self.users = {u.id: u for u in users or []}
        self.groups = list(groups or [])

    async def list_users(self, group_id: int | None, limit: int, offset: int) -> list[UserSummary]:
        rows = [u for u in sorted(self.users.values(), key=lambda u: u.id)
                if group_id is None or u.group_id == group_id]
        return [UserSummary(id=u.id, name=u.name, group_id=u.group_id, opted_in=u.opted_in)
                for u in rows[offset:offset + limit]]

    async def list_groups(self) -> list[UserGroup]:
        return sorted(self.groups, key=lambda g: g.name)

    async def get_user(self, user_id: int) -> User | None:
        return self.users.get(user_id)

    async def save_user(self, user: User) -> User:
        self.users[user.id] = user
        return user


class InMemoryNoticeStore:
    def __init__(self, group_ids: list[int], users: InMemoryUserStore | None = None):
        self.group_ids = set(group_ids)
        self.users = users or InMemoryUserStore()
        self.notices: dict[int, NoticeSummary] = {}
        self.group_of: dict[int, int] = {}    # notice id -> group id
        self.author_of: dict[int, int] = {}   # notice id -> staff id
        self.messages: list[tuple[int, int, str, str | None]] = []  # one per message sent or failed

    async def group_exists(self, group_id: int) -> bool:
        return group_id in self.group_ids

    async def add_notice(self, text: str, group_id: int, send_at: datetime,
                         author_id: int) -> NoticeSummary:
        notice = NoticeSummary(id=len(self.notices) + 1, text=text,
                               send_at=send_at, status="scheduled")
        self.notices[notice.id] = notice
        self.group_of[notice.id] = group_id
        self.author_of[notice.id] = author_id
        return notice

    async def get_notice(self, notice_id: int) -> NoticeSummary | None:
        return self.notices.get(notice_id)

    async def list_notices(self, limit: int) -> list[NoticeSummary]:
        latest_first = sorted(self.notices.values(), key=lambda n: n.send_at, reverse=True)
        return latest_first[:limit]

    async def set_status(self, notice_id: int, status: str) -> None:
        self.notices[notice_id] = self.notices[notice_id].model_copy(update={"status": status})

    async def list_recipients(self, notice_id: int) -> list[Recipient]:
        group_id = self.group_of[notice_id]
        return [Recipient(user_id=u.id, phone=u.phone)
                for u in sorted(self.users.users.values(), key=lambda u: u.id)
                if u.group_id == group_id and u.opted_in]

    async def record_message(self, notice_id: int, user_id: int, status: str,
                             provider_message_id: str | None) -> None:
        self.messages.append((notice_id, user_id, status, provider_message_id))


class FakeSmsClient:
    """Implements SmsClient without sending anything, so no message reaches a real phone."""

    def __init__(self, failing: set[str] | None = None):
        self.sent: list[tuple[str, str]] = []  # (phone, text) per message accepted
        self.failing = failing or set()        # numbers the fake provider rejects

    async def send(self, phone: str, text: str) -> str:
        # Record the message and return a fake provider message id, or raise
        # SmsError for a number in self.failing. Never calls the SMS provider.
        if phone in self.failing:
            raise SmsError("rejected by the fake provider")
        self.sent.append((phone, text))
        return f"fake-{len(self.sent)}"
