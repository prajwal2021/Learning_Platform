# tests/test_users.py
import pytest
from pydantic import ValidationError
from app.interfaces.auth import Staff
from app.interfaces.users import User, UserGroup, UserUpdate
from app.services.users import Users
from tests.stubs import InMemoryUserStore

EDITOR = Staff(id=1, email="staff.member@example.org", role="editor")
VIEWER = Staff(id=2, email="viewer@example.org", role="viewer")


def three_users():
    return InMemoryUserStore(
        users=[
            User(id=1, name="A", phone="+15555550101", group_id=1, opted_in=True),
            User(id=2, name="B", phone="+15555550102", group_id=1, opted_in=False),
            User(id=3, name="C", phone="+15555550103", group_id=2, opted_in=True),
        ],
        groups=[UserGroup(id=2, name="Group 2"), UserGroup(id=1, name="Group 1")],
    )


@pytest.mark.asyncio
async def test_list_users_returns_everyone_without_a_group():
    assert [u.id for u in await Users(three_users()).list_users()] == [1, 2, 3]


@pytest.mark.asyncio
async def test_list_users_returns_only_the_group_when_given():
    assert [u.id for u in await Users(three_users()).list_users(group_id=1)] == [1, 2]


@pytest.mark.asyncio
async def test_list_users_returns_one_page():
    users = Users(three_users())
    assert [u.id for u in await users.list_users(limit=2, offset=1)] == [2, 3]


@pytest.mark.asyncio
@pytest.mark.parametrize("limit, offset", [(0, 0), (201, 0), (50, -1)])
async def test_list_users_rejects_a_page_outside_the_limits(limit, offset):
    with pytest.raises(ValueError):
        await Users(three_users()).list_users(limit=limit, offset=offset)


@pytest.mark.asyncio
async def test_list_rows_leave_out_the_phone_number():
    row = (await Users(three_users()).list_users())[0]
    assert "phone" not in row.model_dump()


@pytest.mark.asyncio
async def test_list_groups_is_ordered_by_name():
    assert [g.name for g in await Users(three_users()).list_groups()] == ["Group 1", "Group 2"]


@pytest.mark.asyncio
async def test_get_user_rejects_unknown_id():
    with pytest.raises(LookupError):
        await Users(three_users()).get_user(99)


@pytest.mark.asyncio
async def test_update_user_changes_only_the_fields_sent():
    updated = await Users(three_users()).update_user(1, UserUpdate(opted_in=False), EDITOR)
    assert updated.opted_in is False
    assert updated.phone == "+15555550101"


@pytest.mark.asyncio
async def test_update_user_denies_a_viewer():
    store = three_users()
    with pytest.raises(PermissionError):
        await Users(store).update_user(1, UserUpdate(opted_in=False), VIEWER)
    assert store.users[1].opted_in is True


@pytest.mark.asyncio
async def test_update_user_formats_the_phone_number():
    updated = await Users(three_users()).update_user(1, UserUpdate(phone="+1 555 555 0199"), EDITOR)
    assert updated.phone == "+15555550199"


@pytest.mark.asyncio
async def test_update_user_rejects_a_phone_number_without_a_plus():
    with pytest.raises(ValueError):
        await Users(three_users()).update_user(1, UserUpdate(phone="555-0101"), EDITOR)


def test_user_update_rejects_fields_a_caller_may_not_set():
    with pytest.raises(ValidationError):
        UserUpdate.model_validate({"group_id": 2})


def test_user_update_rejects_null():
    with pytest.raises(ValidationError):
        UserUpdate.model_validate({"name": None})
