# tests/test_notices.py
import pytest
from datetime import datetime, timedelta, timezone
from app.interfaces.users import User
from app.services.notices import Notices
from tests.stubs import FakeSmsClient, InMemoryNoticeStore, InMemoryUserStore


def in_one_hour():
    return datetime.now(timezone.utc) + timedelta(hours=1)


@pytest.mark.asyncio
async def test_schedule_notice_stores_a_scheduled_notice():
    notices = Notices(InMemoryNoticeStore(group_ids=[1]))
    notice = await notices.schedule_notice("Office closed Friday", group_id=1,
                                           send_at=in_one_hour(), author_id=1)
    assert notice.status == "scheduled"
    assert await notices.list_notices() == [notice]


@pytest.mark.asyncio
async def test_schedule_notice_rejects_empty_text():
    notices = Notices(InMemoryNoticeStore(group_ids=[1]))
    with pytest.raises(ValueError):
        await notices.schedule_notice("   ", group_id=1, send_at=in_one_hour(), author_id=1)


@pytest.mark.asyncio
async def test_schedule_notice_rejects_unknown_group():
    notices = Notices(InMemoryNoticeStore(group_ids=[1]))
    with pytest.raises(ValueError):
        await notices.schedule_notice("Office closed Friday", group_id=99,
                                      send_at=in_one_hour(), author_id=1)


@pytest.mark.asyncio
async def test_schedule_notice_rejects_past_send_time():
    notices = Notices(InMemoryNoticeStore(group_ids=[1]))
    past = datetime.now(timezone.utc) - timedelta(minutes=5)
    with pytest.raises(ValueError):
        await notices.schedule_notice("Office closed Friday", group_id=1,
                                      send_at=past, author_id=1)


@pytest.mark.asyncio
async def test_schedule_notice_rejects_send_time_without_time_zone():
    notices = Notices(InMemoryNoticeStore(group_ids=[1]))
    no_zone = datetime.now() + timedelta(hours=1)
    with pytest.raises(ValueError):
        await notices.schedule_notice("Office closed Friday", group_id=1,
                                      send_at=no_zone, author_id=1)


@pytest.mark.asyncio
async def test_schedule_notice_sends_no_messages():
    sms = FakeSmsClient()
    notices = Notices(InMemoryNoticeStore(group_ids=[1]), sms)
    await notices.schedule_notice("Office closed Friday", group_id=1,
                                  send_at=in_one_hour(), author_id=1)
    assert sms.sent == []


def group_one():
    return InMemoryUserStore([
        User(id=1, name="A", phone="+15555550101", group_id=1, opted_in=True),
        User(id=2, name="B", phone="+15555550102", group_id=1, opted_in=False),
        User(id=3, name="C", phone="+15555550103", group_id=2, opted_in=True),
    ])


@pytest.mark.asyncio
async def test_send_notice_reaches_opted_in_users_in_the_group_only():
    store, sms = InMemoryNoticeStore(group_ids=[1, 2], users=group_one()), FakeSmsClient()
    notices = Notices(store, sms)
    notice = await notices.schedule_notice("Office closed Friday", group_id=1,
                                           send_at=in_one_hour(), author_id=1)
    await notices.send_notice(notice.id)
    assert sms.sent == [("+15555550101", "Office closed Friday")]
    assert (await store.get_notice(notice.id)).status == "sent"
    assert store.messages == [(notice.id, 1, "sent", "fake-1")]


@pytest.mark.asyncio
async def test_send_notice_sets_sending_before_the_first_message():
    store = InMemoryNoticeStore(group_ids=[1], users=group_one())
    seen = []

    class RecordingSms(FakeSmsClient):
        async def send(self, phone, text):
            seen.append((await store.get_notice(1)).status)
            return await super().send(phone, text)

    notices = Notices(store, RecordingSms())
    notice = await notices.schedule_notice("Office closed Friday", group_id=1,
                                           send_at=in_one_hour(), author_id=1)
    await notices.send_notice(notice.id)
    assert seen == ["sending"]


@pytest.mark.asyncio
async def test_send_notice_marks_failed_and_logs_no_phone_number(caplog):
    store = InMemoryNoticeStore(group_ids=[1], users=group_one())
    notices = Notices(store, FakeSmsClient(failing={"+15555550101"}))
    notice = await notices.schedule_notice("Office closed Friday", group_id=1,
                                           send_at=in_one_hour(), author_id=1)
    await notices.send_notice(notice.id)
    assert (await store.get_notice(notice.id)).status == "failed"
    assert store.messages == [(notice.id, 1, "failed", None)]
    assert "user 1" in caplog.text and "5550101" not in caplog.text


@pytest.mark.asyncio
async def test_send_notice_rejects_unknown_notice():
    notices = Notices(InMemoryNoticeStore(group_ids=[1]), FakeSmsClient())
    with pytest.raises(LookupError):
        await notices.send_notice(42)


@pytest.mark.asyncio
async def test_send_notice_refuses_a_notice_already_sent():
    store = InMemoryNoticeStore(group_ids=[1], users=group_one())
    notices = Notices(store, FakeSmsClient())
    notice = await notices.schedule_notice("Office closed Friday", group_id=1,
                                           send_at=in_one_hour(), author_id=1)
    await notices.send_notice(notice.id)
    with pytest.raises(ValueError):
        await notices.send_notice(notice.id)
