# tests/test_api.py
# Calls the endpoints through httpx, with fresh stubs for each test.
from datetime import datetime, timedelta, timezone
import httpx
import pytest
import pytest_asyncio
from app.db import stores
from app.interfaces.users import User, UserGroup
from app.main import app
from tests.stubs import FakeSmsClient, InMemoryNoticeStore, InMemoryUserStore

PASSWORD = "test-only-password"  # STUB_STAFF_PASSWORD in tests/conftest.py


@pytest_asyncio.fixture
async def anonymous():
    users = InMemoryUserStore(
        users=[User(id=1, name="A", phone="+15555550101", group_id=1, opted_in=True)],
        groups=[UserGroup(id=1, name="Group 1")])
    notices = InMemoryNoticeStore(group_ids=[1], users=users)
    app.dependency_overrides[stores.get_user_store] = lambda: users
    app.dependency_overrides[stores.get_notice_store] = lambda: notices
    app.dependency_overrides[stores.get_sms_client] = lambda: FakeSmsClient()
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        yield client
    app.dependency_overrides.clear()


async def sign_in(client, email):
    response = await client.post("/v1/auth/login", json={"email": email, "password": PASSWORD})
    assert response.status_code == 204
    return client


@pytest.mark.asyncio
async def test_sign_in_returns_204_and_sets_the_session_cookie(anonymous):
    response = await anonymous.post("/v1/auth/login",
                                    json={"email": "staff.member@example.org", "password": PASSWORD})
    assert response.status_code == 204
    assert "session" in response.cookies


@pytest.mark.asyncio
async def test_routes_need_a_session(anonymous):
    assert (await anonymous.get("/v1/users")).status_code == 401


@pytest.mark.asyncio
async def test_schedule_then_send_now(anonymous):
    editor = await sign_in(anonymous, "staff.member@example.org")
    next_week = (datetime.now(timezone.utc) + timedelta(days=7)).isoformat()
    created = await editor.post("/v1/notices", json={"text": "Office closed Friday",
                                                     "group_id": 1, "send_at": next_week})
    assert created.status_code == 201
    notice_id = created.json()["id"]
    assert (await editor.post(f"/v1/notices/{notice_id}/send")).status_code == 204
    assert (await editor.get("/v1/notices")).json()[0]["status"] == "sent"


@pytest.mark.asyncio
async def test_groups_route_is_not_read_as_a_user_id(anonymous):
    editor = await sign_in(anonymous, "staff.member@example.org")
    assert (await editor.get("/v1/users/groups")).json() == [{"id": 1, "name": "Group 1"}]


@pytest.mark.asyncio
async def test_page_size_above_the_maximum_is_rejected(anonymous):
    editor = await sign_in(anonymous, "staff.member@example.org")
    assert (await editor.get("/v1/users?limit=1000")).status_code == 400


@pytest.mark.asyncio
async def test_viewer_cannot_change_a_user(anonymous):
    viewer = await sign_in(anonymous, "viewer@example.org")
    response = await viewer.patch("/v1/users/1", json={"phone": "+15555550199"})
    assert response.status_code == 403


@pytest.mark.asyncio
async def test_viewer_cannot_send_a_notice(anonymous):
    viewer = await sign_in(anonymous, "viewer@example.org")
    assert (await viewer.post("/v1/notices/1/send")).status_code == 403


@pytest.mark.asyncio
async def test_patch_cannot_set_group_id(anonymous):
    editor = await sign_in(anonymous, "staff.member@example.org")
    assert (await editor.patch("/v1/users/1", json={"group_id": 2})).status_code == 422


class BrokenUserStore(InMemoryUserStore):
    async def save_user(self, user):
        raise RuntimeError("connection lost")


@pytest.mark.asyncio
async def test_unexpected_error_returns_no_internal_detail(anonymous):
    broken = BrokenUserStore(users=[User(id=1, name="A", phone="+15555550101",
                                         group_id=1, opted_in=True)])
    app.dependency_overrides[stores.get_user_store] = lambda: broken
    transport = httpx.ASGITransport(app=app, raise_app_exceptions=False)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        editor = await sign_in(client, "staff.member@example.org")
        response = await editor.patch("/v1/users/1", json={"phone": "+15555550199"})
    assert response.status_code == 500
    assert response.text == "Internal Server Error"
